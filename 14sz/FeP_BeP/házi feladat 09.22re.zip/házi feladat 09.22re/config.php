<?php
$devlopment = false;

$secret = [
    'mysqlHost' => 'localhost',
    'mysqlUser' => 'root',
    'mysqlPassword' => '',
    'mysqlDb' => 'hazi_09_22',
];
