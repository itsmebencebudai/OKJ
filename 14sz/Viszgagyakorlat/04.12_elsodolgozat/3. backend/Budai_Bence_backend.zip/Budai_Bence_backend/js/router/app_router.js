var express = require('express');

var router = new express.Router(); 

module.exports = router;