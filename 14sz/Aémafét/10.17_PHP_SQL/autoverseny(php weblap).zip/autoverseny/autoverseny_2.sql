-- Active: 1697197325232@@127.0.0.1@3306@autoverseny_2

CREATE DATABASE autoverseny_2
    DEFAULT CHARACTER SET = 'utf8'
    COLLATE utf8_hungarian_ci;
